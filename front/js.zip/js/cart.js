/*TODO: 
    - pull each product price object from Product.js to save in priceObj variable
    - create initialObj function to pull each item price data

*/    
//const priceObj = {};
console.log (priceObj);

const getAllUrl = 'http://localhost:3000/api/products/';
fetch(getAllUrl)

  .then((response) => response.json())
  .then((data) => {
    //console.log(data);
    generateCartItem(data);
    //initialObj (data);
  });

/* TODO: 
  - PULL all ordered items from locaslStorage to display on cart page
*/
let orderedItems = JSON.parse(localStorage.getItem('cart')) ;
let cartItems = document.getElementById('cart__items');
const itemQuantity = document.getElementsByClassName('itemQuantity');



/* function initialObj (productArray)
{
    for ( let i = 0; i < productArray.length; i++)
    {
        priceObj[productArray[i]._id] = productArray[i].price;
    }
} */


let generateCartItem = (productData) =>
{     
    //console.log(productData); 
    
    if (orderedItems.length !== 0)
    {
        orderedItems.forEach((item) => 
        {
           
            let search = productData.find(dataItem =>  dataItem._id === item.id );
            //console.log(search);
            cartItems.innerHTML += 
                `
                    <article class="cart__item" data-id="${item.id}" data-color="${item.color}">
                        <div class="cart__item__img">
                            <img src=${item.imageUrl} alt=${item.altTxt}>
                        </div>
                        <div class="cart__item__content">
                            <div class="cart__item__content__description">
                                <h2>${item.name}</h2>
                                <p>${item.color}</p>
                                <p>€${search.price}</p>
                            </div>
                            <div class="cart__item__content__settings">
                                <div class="cart__item__content__settings__quantity">
                                <p>Qté :  </p>
                                <input type="number" class="itemQuantity" name="itemQuantity" min="1" max="100" value= "${parseInt(item.quantity, 10)}">
                            </div>
                            <div class="cart__item__content__settings__delete">
                                <p class="deleteItem">Delete</p>
                            </div>
                            </div>
                        </div>
                    </article>
                `; 
                
        });
    }  
     
    updateTotal (productData);
    
}

// Use closet() method to remove item
function removeItem(){
    
    const deleteItem = document.getElementsByClassName('deleteItem');
    for ( let i = 0; i < deleteItem.length; i++)
    {

        let deleteButton = deleteItem[i];
        deleteButton.addEventListener('click', function(event){
            let buttonClicked = event.target;
            console.log(buttonClicked.previousElementSibling(".cart__item__content__description"));

           // buttonClicked.closest("cartItem.dataset.id").remove();

        });
    }
    updateTotal();
}

// Quantity change
itemQuantity.addEventListener('change', function quantityChanged(id, color, quantity = 0){
    for (let i = 0; i < orderedItems.length; i++){
        if(orderedItems[i].id === id && orderedItems[i].color === color){
            if(quantity > 0 ){
                orderedItems[i].quantity -= quantity;
            }
            return
        }
    }
    
});



// Calculate total quantity of ordered items
/* function getTotalQuantity(){
    let totalOrderedItems = 0;
    for ( let i = 0; i < orderedItems.length; i++)
    { 
        totalOrderedItems += parseInt(orderedItems.quantity, 10);
    }

    return totalOrderedItems;
}
 */


function updateTotal (productData) 
{
    let totalOrderedItems = 0;
    let totalOrderedItemPrices = 0; 
    orderedItems.forEach((item) => 
    {
        let search = productData.find(dataItem =>  dataItem._id === item.id );
        const totalQuantity = document.getElementById('totalQuantity');
        const totalPrice = document.getElementById('totalPrice');
        
        totalOrderedItems += parseInt(item.quantity, 10);
        
        totalOrderedItemPrices += totalOrderedItems * search.price;
        totalQuantity.innerHTML = totalOrderedItems;
        totalPrice.innerHTML = totalOrderedItemPrices;  
    }); 
    
}

// error message of firstName and lastName && address
let firstName = document.getElementById('firstName');
firstName.addEventListener('input', checkValidName);

// Create validation input name function to check is it valid as requirement?
function checkFirstName ()
{
    let nameRegex = /^[A-Za-z -] {3,32}$/;
    let firstName = document.getElementById('firstName').value;
    const firstNameErrorMsg = document.getElementById('firstNameErrorMsg');

}

function checkLastName ()
{
    let nameRegex = /^[A-Za-z -] {3,32}$/;
    const lastName = document.getElementById('lastName');
    const lastNameErrorMsg = document.getElementById('lastNameErrorMsg');

}

function checkEmail ()
{
    let nameRegex = /^[A-Za-z -] {3,32}$/;
    //add pattern attribute in email DOM pattern=".+@.+\..+"
    const email = document.getElementById('email');
    const emailErrorMsg = document.getElementById('emailErrorMsg');

}

function checkAddress ()
{
    let nameRegex = /^[A-Za-z -] {3,32}$/;
    const address = document.getElementById('address');
    const addressErrorMsg = document.getElementById('addressErrorMsg');
}

function checkCity ()
{
    let nameRegex = /^[A-Za-z -] {3,32}$/;
    const city = document.getElementById('city');
    const cityErrorMsg = document.getElementById('cityErrorMsg');
}


//firstName.addEventListener('input', ($event))
// order 

const order = document.getElementById('order');
order.addEventListener('click', () => {
    const cartOrderForm = document.getElementsByClassName('cart__order__form');
    cartOrderForm.reset;
} );

























//let cartItems = document.getElementById('cart__items');
        
        /* return (cartItems.innerHTML = orderedItems.map((orderItem) => 
        {
            let {color, id, quantiy} = orderItem;
            let search = productData.find((dataItem) => { dataItem._id === id && dataItem.colors === color || [] })
                return
                    `
                    <article class="cart__item" data-id="${search._id}" data-color="${search.colors}">
                        <div class="cart__item__img">
                            <img src=${search.imageUrl} alt=${search.altTxt}>
                        </div>
                        <div class="cart__item__content">
                            <div class="cart__item__content__description">
                                <h2>${search.name}</h2>
                                <p>${search.colors}</p>
                                <p>€${search.price}</p>
                            </div>
                            <div class="cart__item__content__settings">
                                <div class="cart__item__content__settings__quantity">
                                <p>Qté : ${quantiy}</p>
                                <input type="number" class="itemQuantity" name="itemQuantity" min="1" max="100" value="42">
                            </div>
                            <div class="cart__item__content__settings__delete">
                                <p class="deleteItem">Delete</p>
                            </div>
                            </div>
                        </div>
                    </article>
                    `;
            })  
        .join("")); 
          
    };*/ 
/*
<article class="cart__item" data-id="{product-ID}" data-color="{product-color}">
    <div class="cart__item__img">
        <img src="../images/product01.jpg" alt="Photo of a sofa">
    </div>
    <div class="cart__item__content">
        <div class="cart__item__content__description">
        <h2>Name of the product</h2>
        <p>Green</p>
        <p>€42.00</p>
        </div>
        <div class="cart__item__content__settings">
        <div class="cart__item__content__settings__quantity">
            <p>Qté : </p>
            <input type="number" class="itemQuantity" name="itemQuantity" min="1" max="100" value="42">
        </div>
        <div class="cart__item__content__settings__delete">
            <p class="deleteItem">Delete</p>
        </div>
        </div>
    </div>
</article> */

// Create decrement() and increment() functions
/* let cart = JSON.parse(localStorage.getItem(product)) || [];
let search = cart.find((x) => x.id === id) || [];//write it inside generatecart ${search.quantity === undefined ? 0 : search.quantity} 
function decrement (id, color)
{
    let selectedItem = id;
    let selectedColor = color;
    let search = cart.find((x) => x.id === selectedItem.id && x.color === selectedColor);
    if (search === undefined) return;// prevent error happens
    else if (search.quantity === 0) 
    {
        return;
    }    
    else
    {
        search.quantity -= 1;
    }        
    
    update(selectedItem.id);
    //select quantity that not equal zero to save in localStorage only then delect quantiy = 0.
    cart = cart.filter( (x) => x.quantity !== 0);
    console.log(cart);
    
    localStorage.setItem('product', JSON.stringify(cart));  
}

function increment (id, color){
    let selectedItem = id;
    let selectedColor = color;
    let search = cart.find((x) => x.id === selectedId.id && x.color === selectedColor);
    if (search === undefined)
    {
        cart.push({ id: selectedItem.id, color: selectedColor, quantity: 1});
    }
    else 
    {
        search.quantity += 1;
    } 
    
    update(selectedId.id, selectedColor.color)
    localStorage.setItem('product', JSON.stringify(cart));  
    
}

let update = (id) => { let search = cart.find( (x) => x.id === id);
    console.log(search.quantity);
    document.getElementById(id).innerHTML = search.quantity;
    calculation();
}

let calculation = () => { 
    let cartIcon = document.getElementById('cartAmount');
    cartIcon.innerHTML = cart.map( (x) => x.quantity).reduce((x, y) => x + y, 0);
}
calculation(); // to keep amount of selected item in cart run fast 

let generateCartItem = () => {
    if (cart.length !== 0)
    {
        return (shoppingCart.innerHTML = cart.map((x) => {
            console.log(x);
            let {id, color, quantity} = x;
            let search = shopItemsData.find( (y) => y._id === id) || [];
            return `
            <div> calss
            `
        }))
    }
} 
*/